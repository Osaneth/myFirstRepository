﻿//namespace EnrolmentTableAdapters
//{
//    internal class QueriesTableAdapter;
//    {
//    }
//}