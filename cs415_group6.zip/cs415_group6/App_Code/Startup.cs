﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CS415.Startup))]
namespace CS415
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
