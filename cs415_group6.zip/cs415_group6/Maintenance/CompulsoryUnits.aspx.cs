﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Maintenance_CompulsoryUnits : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void fmvCompulsoryUnit_ItemInserting(object sender, FormViewInsertEventArgs e)
    {
        DropDownList ddl = (DropDownList)fmvCompulsoryUnit.FindControl("ddlMajorType");
        DropDownList ddlAtLeast = (DropDownList)fmvCompulsoryUnit.FindControl("ddlAtLeast");
        e.Values["MajorID"] = ddl.SelectedValue;
        e.Values["AtLeast"] = ddlAtLeast.SelectedValue;

    }
}