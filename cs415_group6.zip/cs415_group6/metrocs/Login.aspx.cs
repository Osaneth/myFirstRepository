﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class metrocs_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
        EnrolmentTableAdapters.QueriesTableAdapter ta = new EnrolmentTableAdapters.QueriesTableAdapter();

        ta.countUser(txtusername.Value);
        if (Convert.ToInt32(ta.countUser(txtusername.Value)) == 1)
        {
            if (Convert.ToBoolean(ta.getHold(txtusername.Value)) == false)
            {
                Session["username"] = txtusername.Value.Trim();
                Response.Redirect("/metrocs/Default.aspx");
            }
            else
            {
                lblErrorMessage.Visible = true;
                lblErrorMessage.Text = "You are on hold: Please contact our Student Academic Services. ";
                lblErrorMessage.ForeColor = System.Drawing.Color.Red;
            }
        }
        else
        {
                
        }
    }
}