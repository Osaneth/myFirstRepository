﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class metrocs_Enrolment : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        EnrolmentTableAdapters.QueriesTableAdapter qta = new EnrolmentTableAdapters.QueriesTableAdapter();
        EnrolmentTableAdapters.CompulsoryUnitsTableAdapter ta = new EnrolmentTableAdapters.CompulsoryUnitsTableAdapter();

        //int a = Convert.ToInt32(qta.countUnitID(6));
        int StudentID = 9;
        HiddenField1.Value = StudentID.ToString();
        List<string> list = new List<string>();
        foreach (GridViewRow rows in gdv.Rows)
        {
            Label lbl = (Label)rows.FindControl("lblunit");
            int unitID = Convert.ToInt32(lbl.Text);
            int prerequisiteId = Convert.ToInt32(qta.getPrerequisiteID(unitID));
            if (Convert.ToBoolean(qta.getStudentPassPrereq(prerequisiteId, StudentID)) == true)
            {
                list.Add(Convert.ToString(unitID));
            }
        }
        hdn.Value = string.Join(",", list.ToArray());

    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        EnrolmentTableAdapters.RegistrationDetailTableAdapter ta = new EnrolmentTableAdapters.RegistrationDetailTableAdapter();
        EnrolmentTableAdapters.StudentFeesTableAdapter nta = new EnrolmentTableAdapters.StudentFeesTableAdapter();
        EnrolmentTableAdapters.CompulsoryUnitsTableAdapter qta = new EnrolmentTableAdapters.CompulsoryUnitsTableAdapter();

        //check if unit has prereq

        foreach (GridViewRow row in gdvEnrol.Rows)
        {
            Label lblID = (Label)row.FindControl("lblID");
            Label lblmode = (Label)row.FindControl("lblmode");
            Label lblCampus = (Label)row.FindControl("lblCampus");
            Label lblUnitID = (Label)row.FindControl("lblUnitID");
            CheckBox chk = (CheckBox)row.FindControl("chk");
            
            if (chk.Checked)
            {
                ta.insertIntoRegistration(Convert.ToInt32(lblUnitID.Text), lblmode.Text, Convert.ToInt32(lblID.Text), lblCampus.Text, true, 9);
                qta.updateRegistered(true, Convert.ToInt32(lblID.Text));
                nta.insertIntoFees("Tuition Fees", 450, Convert.ToInt32(lblUnitID.Text), 9);
            }
            gdvEnrol.DataBind();
            Register.DataBind();
        }

    }

    protected void fmvEnrollment_PageIndexChanging(object sender, FormViewPageEventArgs e)
    {

    }

    protected void fmvEnrollment_PageIndexChanged(object sender, EventArgs e)
    {

    }
}


