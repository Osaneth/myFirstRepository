﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;
using System.Configuration;
using System.Data.SqlClient;

public partial class metrocs_Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        GetChartData();
    }
    [WebMethod]
    public static List<object> GetChartData()
    {
        string query = "SELECT UnitDetails_1.CourseCode As PrereqId, guest.Prerequisites.UnitCourseName, guest.UnitDetails.CourseCode As UnitID FROM guest.Prerequisites INNER JOIN guest.UnitDetails ON guest.Prerequisites.UnitID = guest.UnitDetails.UnitID INNER JOIN guest.UnitDetails AS UnitDetails_1 ON guest.Prerequisites.PrereqUnitID = UnitDetails_1.UnitID";
        //query += "FROM guest.Prerequisites INNER JOIN guest.UnitDetails ON guest.Prerequisites.UnitID = guest.UnitDetails.UnitID INNER JOIN guest.UnitDetails AS UnitDetails_1 ON guest.Prerequisites.PrereqUnitID = UnitDetails_1.UnitID";
        string constr = ConfigurationManager.ConnectionStrings["CS415Project_ConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand(query))
            {
                List<object> chartData = new List<object>();
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                con.Open();
                using (SqlDataReader sdr = cmd.ExecuteReader())
                {
                    while (sdr.Read())
                    {
                        chartData.Add(new object[]
                        {
                        sdr["UnitCourseName"], sdr["PrereqId"], sdr["UnitID"]
                        });
                    }
                }
                con.Close();
                return chartData;
            }
        }
    }
}