﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class metrocs_ProgramAudit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        EnrolmentTableAdapters.QueriesTableAdapter qta = new EnrolmentTableAdapters.QueriesTableAdapter();
        int val = Convert.ToInt32(qta.countFailIsNull());
        int val1 = Convert.ToInt32(qta.countFail());
        int total = val + val1;
        
    }
}