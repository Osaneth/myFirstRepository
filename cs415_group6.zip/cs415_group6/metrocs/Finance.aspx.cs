﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class metrocs_Finance : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label lblDateToday = (Label)fmvFees.FindControl("lblDateToday");
        lblDateToday.Text = Convert.ToString(DateTime.Now);
    }
    decimal sumFooterValue = 0;
    protected void gdvFees_DataBound(object sender, GridViewRowEventArgs e)
    {
        
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            sumFooterValue = sumFooterValue + Convert.ToDecimal(((Label)e.Row.FindControl("lblFees")).Text);
            //decimal FinalTotal = Convert.ToDecimal(total) + Convert.ToDecimal(total);
            //e.Row.Cells[5].Text = FinalTotal.ToString();
            //sumFooterValue = FinalTotal;
        }


        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lblTotalFees = (Label)e.Row.FindControl("lblTotalFees");
            lblTotalFees.Text = Convert.ToString(sumFooterValue);
            e.Row.Cells[5].Text = lblTotalFees.Text;
        }
    }

    protected void fmvFees_PageIndexChanging(object sender, FormViewPageEventArgs e)
    {

    }
}