﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration_Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnRegistration_Click(object sender, EventArgs e)
    {

    }

    protected void btnCompulsory_Click(object sender, EventArgs e)
    {
        HiddenField1.Value = Convert.ToString(6);
        GridView1.Visible = true;
        gdvStudent.Visible = false;
        gdvResults.Visible = false;

    }

    protected void btnResult_Click(object sender, EventArgs e)
    {
        hdn.Value = Convert.ToString(6);
        GridView1.Visible = false;
        gdvStudent.Visible = false;
        gdvResults.Visible = true;
    }

    protected void btnDetails_Click(object sender, EventArgs e)
    {
        hdnStudent.Value = Convert.ToString(6);
        gdvStudent.Visible = true;
        GridView1.Visible = false;
        gdvResults.Visible = false;
    }
}